
#include "mcc_generated_files/mcc.h"
#include <stdio.h>
#include <stdlib.h>
#include "hall.h"

long  a,pot_l;
long  pot_h;
long  pot;
char duty[]="aygun";
int i;
long millis;
int8_t sequence_step;

/*
                         Main application
 */
void PWM_ayarlari(){
    TRISC|=0b00111100;//C PORT C2 C3 C4 C5 INPUT
    TRISD=0b01100000; //D PORT D6 D5       INPUT
    ECCP1AS=0x00;
    PR2=100;
    ECCP1AS=0x00;
    CCPR1L=0;
    CCP1CON|=0b00001100;
    T2CON=0b00000110;
    PSTRCON=0b00000000;
    TRISC&=~0b00111100;//C PORT C2 C3 C4 C5 OUTPUT
    TRISD&=~0b01100000;//D PORT D6 D5       OUTPUT
    ECCP1AS&=~0b01110000;
}
void Set_PWM(){ 
    CCPR1L=(pot_h>>2);
    CCP1CONbits.DC1B1=((pot_h>>1)&1);
    CCP1CONbits.DC1B0=pot_h&1;
}

void Serial_println(char *s){
    int i =0;
    while(s[i]!='\0'){
        EUSART_Write(s[i]);
        i++;
    }
}
void Timer0_ayarlari(){
    T0CON   =0b01000101;
    INTCON |=0b00100000;
    T0CON  |=0b10000000;
    TMR0L=4;
}
void kesme_ayarlari() {
        //PORTB Config
    TRISB = 0xE0; //PORTB bits 7,6,5 are inputs
    INTCON  = 0b11001000;    // Enable  Global and periferal intterrupt
    INTCON2 = 0b00001001;   // Set RB int as high priority intterrupt
    WPUB    = 0b11100000;   //Set PORTB pins 7,6 and 5 weak input pull-up
    IOCB    = 0b11100000;   //Set interrupt on change pin activated
}

void __interrupt() isr(void) {
    ///Hall Interrups Occurs
    if (INTCONbits.RBIF == 1) {

        sequence_step = ((PORTB >> 5)&7);

        sprintf(duty, "%d \n", sequence_step);
        Serial_println(duty);
        set_next_step(sequence_step);
        INTCONbits.RBIF = 0;
    }
    //Millis variable update every 1 Second!!!
    if (INTCONbits.TMR0IF == 1) {
        if (i == 1000) {
            millis++;
            sprintf(duty, "%ld \n", millis);
            Serial_println(duty);
            i = 0;
        }
        i++;
        TMR0L = 4;
        INTCONbits.TMR0IF = 0;
    }

}
void pot_okuma(){
    TRISA|=1;
    ADCON0=1;
    ADCON1=0b10001111;
    ADCON2=0b10001010;
}
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    Serial_println("samet");
    pot_okuma();
    kesme_ayarlari();
    PWM_ayarlari();
    Timer0_ayarlari();
    while (1)
    {
        // Add your application code
          GO_DONE=1;
        while(GO_DONE==1){
        }
            pot=ADRESL;
            pot|=ADRESH<<8;
            pot_h=pot*400/1024;
            Set_PWM();
    }
}
/**
 End of File
*/