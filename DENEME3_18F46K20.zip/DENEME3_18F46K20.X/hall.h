/* 
 * File:   hall.h
 * Author: SerSam
 *
 * Created on 24 Haziran 2022 Cuma, 01:51
 */
#define _XTAL_FREQ 64000000     //64 MHz
#ifndef HALL_H
#define	HALL_H

#ifdef	__cplusplus
extern "C" {
#endif
#ifdef	__cplusplus
    
}
#endif
void set_next_step(int sequence_step);
void AH_BL();
void AH_CL();
void BH_AL();
void BH_CL();
void CH_AL();
void CH_BL();
#endif	/* HALL_H */

