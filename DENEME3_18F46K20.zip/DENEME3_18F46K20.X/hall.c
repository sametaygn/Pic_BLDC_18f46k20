/*
 * File:   hall.c
 * Author: SerSam
 *
 * Created on 24 Haziran 2022 Cuma, 01:57
 */

#define _XTAL_FREQ 64000000     //64 MHz
#include <xc.h>
#include <pic18f46k20.h>

void AH_BL() {
    PSTRCON = 0b00000000;
    LATD &= ~0b01100000;
    LATC &= ~0b00111100;
    __delay_us(10);
    LATC |= 0x10;
    PSTRCON = 0b00000001; //open a phase timer
}

void AH_CL() {
    PSTRCON = 0b00000000;
    LATD &= ~0b01100000;
    LATC &= ~0b00111100;
    __delay_us(10);
    LATC |= 0x08;
    PSTRCON = 0b00000001; //open a phase timer
}

void BH_AL() {
    PSTRCON = 0b00000000;
    LATD &= ~0b01100000;
    LATC &= ~0b00111100;
    __delay_us(10);
    LATC = 0x20;
    PSTRCON = 0b00000010; //open b phase timer
}

void BH_CL() {
    PSTRCON = 0b00000000;
    LATD &= ~0b01100000;
    LATC &= ~0b00111100;
    __delay_us(10);
    LATC |= 0x08;
    PSTRCON = 0b00000010; //open b phase timer
}

void CH_AL() {
    PSTRCON = 0b00000000;
    LATD &= ~0b01100000;
    LATC &= ~0b00111100;
    __delay_us(10);
    LATC = 0x20;
    PSTRCON = 0b00000100; //open c phase timer
}

void CH_BL() {
    PSTRCON = 0b00000000;
    LATD &= ~0b01100000;
    LATC &= ~0b00111100;
    __delay_us(10);
    LATC |= 0x10;
    PSTRCON = 0b00000100; //open c phase timer
}

void set_next_step(int sequence_step) {
    switch (sequence_step) {
        case 1:
            AH_CL();
            break;
        case 2:
            BH_AL();
            break;
        case 3:
            BH_CL();
            break;
        case 4:
            CH_BL();
            break;
        case 5:
            AH_BL();
            break;
        case 6:
            CH_AL();
            break;
        default:
            PSTRCON = 0b00000000; //close all pwm signal
            break;
    }
        
    }



